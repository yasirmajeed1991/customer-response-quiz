<?php
// Start the session
session_start();
// Include your database connection
include_once "admin/connection.php";
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["capturedImageData"])) {
        // Get the captured image data
        $capturedImageData = $_POST["capturedImageData"];
        
        // Convert base64 image data to binary
        $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $capturedImageData));

        // Generate a unique filename
        $filename = uniqid() . '.png';

        // Specify the folder to save the image
        $folderPath = 'images/CameraImages/';

        // Save the image to the folder
        $filePath = $folderPath . $filename;
        file_put_contents($filePath, $imageData);
        $_POST['answer'] = $filePath;
        // Store the image path or filename in your database
        // Insert SQL query here to store $filePath in your database

        // Proceed with other form processing or redirect as needed
    }
    if (!empty($_POST["voicerecording"])) {
         // Define the directory to store recordings
        $recordingsDir = 'recordings/';

        // Generate a unique filename for the recording
        $filename = uniqid('recording_') . '.webm';

        // Get the recording data from the hidden input field
        $recordingData = $_POST['voicerecording'];

        // Decode the recording data from base64
        $decodedData = base64_decode(explode(',', $recordingData)[1]);

        // Save the recording file to the recordings directory
        if (file_put_contents($recordingsDir . $filename, $decodedData) !== false) {
            // File saved successfully, you can now store the filename or path to the database
            // For demonstration purposes, let's just echo the filename
           // echo "Recording saved as: $filename";
           $_POST['answer'] = 'recordings/'.$filename;
        } 
    }


    // Process the submitted form data
    // Code to save the answer to the database and perform any necessary operations
     // Prepare the insert statement
     $insertSql = "INSERT INTO user_response (user_id, question_id, answer, elapsed_time) VALUES (?, ?, ?, ?)";
     $insertStmt = $link->prepare($insertSql);
 
     // Bind the parameters
     $insertStmt->bind_param("ssss", $_SESSION['user_id'], $_SESSION['currentQuestionId'], $_POST['answer'], $_POST['elapsed_time']);
 
     // Execute the statement
     if ($insertStmt->execute()) {
         echo "Answer submitted successfully.";
     } else {
         echo "Error: " . $insertStmt->error;
     }
 
     // Close the statement
     $insertStmt->close();


     // Shift the array to remove the answered question
     if(isset($_SESSION['questionIds']) && !empty($_SESSION['questionIds'])) {
        // Shift the first value from questionIds array and store it in currentQuestionId
        $_SESSION['currentQuestionId'] = array_shift($_SESSION['questionIds']);
    } else {
        // If questionIds array is empty, set currentQuestionId to an empty string
        $_SESSION['currentQuestionId'] = "";
    }
    

    // Redirect back to the quiz page
    $_SESSION['questionNo']++;
    header("Location: practice_mode.php");
    exit(); // Ensure script execution stops after redirection
}
?>
