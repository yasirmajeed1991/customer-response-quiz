<?php
// Include your database connection
include_once "admin/connection.php"; 






if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user information
    $name = $_POST["name"];
    $number = $_POST["number"];
    //$responses = $_POST["responses"];

    // Retrieve quiz responses
    $responses = "";
    foreach ($_POST as $key => $value) {
        if (strpos($key, "question") === 0) {
            $responses .= "$key: <b>$value</b>  <hr><br>";
        }
    }

    // Retrieve timer value
    $timer = $_POST["timerValue"];

    // Insert data into the database
    $insertSql = "INSERT INTO quiz_results (name, number, responses, timer) VALUES (?, ?, ?, ?)";
    $stmt = $link->prepare($insertSql);

    if ($stmt) {
        $stmt->bind_param("ssss", $name, $number, $responses, $timer);
        $stmt->execute();

        echo "Quiz submitted successfully!";
        
        //send mail 
        
        $api_url = 'https://api.resend.com/emails';
        $api_key = 're_Ee4Qes4U_N9yR1i4wzZ6swKUU3oZZMn9u';
        
        $data = array(
            'from' => 'onboarding@resend.dev',
            'to' => 'flowers22888@hotmail.com',
            'subject' => 'New Submission',
            'html' => '<p>New quiz <strong>Submission</strong>!</p>',
        );
        
        $ch = curl_init($api_url);
        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Content-Type: application/json',
        ));
        
        $response = curl_exec($ch);
        
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
        } else {
            echo 'API Response: ' . $response;
        }
        
        curl_close($ch);
        

        $stmt->close();
       header("location: ./thank_you.php");

    } else {
        echo "Error preparing statement: " . $link->error;
    }

    // Close the database connection
    $link->close();

    
    
    
    
    
    
}
?>
