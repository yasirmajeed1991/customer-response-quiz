<?php 
ob_start(); // Start output buffering
session_start();

// Check if user ID and mode are set in session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['mode'])) {
    // Redirect to login page or display an error message
    header("Location: index.php");
    exit;
}
include_once "admin/connection.php"; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Step Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<style>
        #image_upload {
            padding-top: 15px;
            text-align: center;
            margin: 20px auto;
            border: 2px dashed #ccc;
            border-radius: 10px;
            padding: 20px;
            max-width: 500px;
            background-color: #f9f9f9;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group p {
            font-size: 18px;
            font-weight: bold;
        }
        #fileInput {
            display: block;
            margin: 10px auto;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 80%;
        }
        #imagePreview {
            display: none;
            max-width: 100%;
            max-height: 300px;
            margin-top: 15px;
        }
    </style>
<body >
<script>
        // Function to start the timer
        function startTimer() {
            var startTime = localStorage.getItem("startTime"); // Get the start time from local storage
            if (!startTime) {
                startTime = new Date().getTime(); // If start time is not stored, get the current time
                localStorage.setItem("startTime", startTime); // Store the start time in local storage
            }

            setInterval(updateTimer, 1000); // Update the timer every second
        }

        // Function to update the timer display
        function updateTimer() {
            var startTime = parseInt(localStorage.getItem("startTime")); // Parse the start time from local storage as an integer
            var currentTime = new Date().getTime(); // Get the current time
            var elapsedTime = currentTime - startTime; // Calculate the elapsed time in milliseconds
            var seconds = Math.floor(elapsedTime / 1000); // Convert milliseconds to seconds
            document.getElementById("elapsedTimeDisplay").innerHTML = "Elapsed time: " + seconds + " seconds";
        }

        // Function to stop the timer and store the elapsed time
        function stopTimer() {
            clearInterval(updateTimer); // Stop updating the timer
            var startTime = parseInt(localStorage.getItem("startTime")); // Parse the start time from local storage as an integer
            localStorage.removeItem("startTime"); // Remove the start time from local storage
            var currentTime = new Date().getTime(); // Get the current time
            var elapsedTime = currentTime - startTime; // Calculate the elapsed time in milliseconds
            var seconds = Math.floor(elapsedTime / 1000); // Convert milliseconds to seconds
            if (!isNaN(seconds)) {
                document.getElementById("elapsedTimeField").value = seconds; // Store the elapsed time in the hidden field if it's a valid number
            }
        }
    </script>
<div class="container mt-5">
<div id="elapsedTimeDisplay" style=" text-align: right;"></div>

    <form id="quizForm" action="practice_submit.php" enctype="multipart/form-data" method="post">
    <input type="hidden" id="elapsedTimeField" name="elapsed_time">
        <?php
        // Check if there are remaining questions in the session
        if (!empty($_SESSION['currentQuestionId'])) {
           
            // Get the ID of the first question
            $currentQuestionId=$_SESSION['currentQuestionId'];

            // Fetch the details of the current question from the database
            $questionSql = "SELECT * FROM questions WHERE id = ?";
            $questionStmt = $link->prepare($questionSql);
            $questionStmt->bind_param("i", $currentQuestionId);
            $questionStmt->execute();
            $questionResult = $questionStmt->get_result();

            // Check if the question exists
            if ($questionResult->num_rows > 0) {
                // Fetch the question details
                $questionRow = $questionResult->fetch_assoc();

                // Display the question details
                
                echo '<div class="form-step">';
                echo '<h2>Question ' . $_SESSION['questionNo'] . ':</h2>';
                echo '<div class="form-group">';
                echo '<label for="question' . $questionRow['id'] . '">' . $questionRow['question_text'] . '</label>';
                // Display other question details as needed

                // Check if it's a radio-type question
                if ($questionRow['question_type'] == 'radio') {
                    // Fetch choices for radio questions
                    $questionId = $questionRow['id'];
                    $choicesSql = "SELECT choice_text FROM choices WHERE question_id = $questionId";
                    $choicesResult = $link->query($choicesSql);

                    if ($choicesResult->num_rows > 0) {
                        echo '<div class="form-check">';
                        $choices = ['a', 'b', 'c', 'd', 'e', 'f']; // Add more letters if needed

                        $index = 0; // Initialize index for choices array

                        while ($choice = $choicesResult->fetch_assoc()) {
                            $letter = $choices[$index]; // Get the corresponding letter from the choices array

                            echo '<input type="radio" class="form-check-input" name="answer" value="' . $choice['choice_text']  . '" required>';
                            echo '<label class="form-check-label" for="question' . $_SESSION['questionNo'] . '">' . $letter . '. ' . $choice['choice_text'] . '</label><hr><br>';

                            $index++; // Move to the next letter
                        }
                        echo '</div>';
                    }
                }

              
                if ($questionRow['question_type'] == 'image') {
                     // Fetch image path from question_image table
                        $imageSql = "SELECT image_path FROM question_image WHERE question_id = ?";
                        $imageStmt = $link->prepare($imageSql);
                        $imageStmt->bind_param("i", $currentQuestionId);
                        $imageStmt->execute();
                        $imageResult = $imageStmt->get_result();
                        
                        // Check if image path exists
                        if ($imageResult->num_rows > 0) {
                            // Fetch image path
                            $imageRow = $imageResult->fetch_assoc();
                            $imagePath = $imageRow['image_path'];

                            // Display the image
                            echo '<div style="margin-top:25px;  margin-bottom:25px;"> <img style="width: auto; max-width: 100%;"  src="' . $imagePath . '" alt="Question Image" ></div>';
                        } else {
                            // No image found for the question
                            echo 'No image found for this question.';
                           
                        }

                        // Close the statement
                        $imageStmt->close();
                  }
                  if($questionRow['answer_type']!= 'radio'){
                    echo '<p><h3>Answer:</h3></p>';
                    }
                  if ($questionRow['answer_type'] == 'text') {
                        echo '<input type="text" class="form-control" placeholder="enter your answer" id="answer" name="answer" required style="margin-bottom: 20px;">';
                }
                if ($questionRow['answer_type'] == 'image' || $questionRow['answer_type'] == 'cameraImage') {
                    echo '<style>
                    /* Style for anchor buttons */
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        margin: 10px;
                        background-color: #007bff;
                        color: #fff;
                        text-decoration: none;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                    }
                   
                
                    /* Container styles */
                    .row {
                        display: flex;
                            margin-bottom: 33px;
                            margin-left: 30px;
                    }
                
                    #webcamContainer {
                        width: auto; 
                        max-width: 100%;
                        position: relative;
                    }
                
                    #capturedImage {
                        width: auto; 
                        max-width: 100%;
                        display: none;
                    }
                    #retakeButton {
                        background-color: #000;
                        color: #fff;
                    }
                </style>
                
                <div id="imageSelection" style="margin-bottom:50px;">
        
        <button type="button" id="uploadImageButton" class="button">Upload Image File</button>
        <button type="button" id="captureImageButton" class="button">Capture Camera Image</button>
    </div>

    <div id="imageUploadSection" style="display: none;">
        <div id="image_upload">
            <div class="form-group" id="image_file">
                <p><strong>Please upload an image</strong></p>
                <input type="file" class="form-control" name="fileInput" id="fileInput" accept="image/*" onchange="previewImage(event)">
                <img id="imagePreview" src="#" alt="Image Preview" style="display: none; max-width: 100%; max-height: 300px; padding-top: 15px;">
            </div>
        </div>
    </div>

    <div id="cameraCaptureSection" style="display: none;">
        <!-- Webcam and Capture Elements -->
        <div id="webcamContainer">
            <video id="webcamVideo" width="auto" max-width="100%" autoplay></video>
            <img id="capturedImage" src="" alt="Captured Image" style="display: none;">
        </div>

        <div id="buttonContainer">
            <button type="button" id="captureButton" class="button">Capture</button>
            <button type="button" id="retakeButton" class="button" style="display: none;">Retake</button>
        </div>

        <!-- Hidden Field to Store Captured Image Data -->
        <input type="hidden" id="capturedImageData" name="capturedImageData">
    </div>
                
                <script>
                    // Add this script at the end of your HTML body or within a <script> tag
document.addEventListener("DOMContentLoaded", function() {
    const uploadImageButton = document.getElementById("uploadImageButton");
    const captureImageButton = document.getElementById("captureImageButton");
    const imageUploadSection = document.getElementById("imageUploadSection");
    const cameraCaptureSection = document.getElementById("cameraCaptureSection");
    const captureButton = document.getElementById("captureButton");
    const retakeButton = document.getElementById("retakeButton");
    const capturedImageDataInput = document.getElementById("capturedImageData");
    const capturedImage = document.getElementById("capturedImage");

    uploadImageButton.addEventListener("click", function() {
        imageUploadSection.style.display = "block";
        cameraCaptureSection.style.display = "none";
    });

    captureImageButton.addEventListener("click", function() {
        cameraCaptureSection.style.display = "block";
        imageUploadSection.style.display = "none";

        // Initialize webcam and capture functionality
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
                const webcamVideo = document.getElementById("webcamVideo");
                webcamVideo.srcObject = stream;
            })
            .catch(function(err) {
                console.error("Error accessing webcam:", err);
            });
    });

    captureButton.addEventListener("click", function() {
        const webcamVideo = document.getElementById("webcamVideo");
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");

        canvas.width = webcamVideo.videoWidth;
        canvas.height = webcamVideo.videoHeight;
        context.drawImage(webcamVideo, 0, 0, canvas.width, canvas.height);

        const imageDataURL = canvas.toDataURL("image/png");

        capturedImage.src = imageDataURL;
        capturedImage.style.display = "block";
        webcamVideo.style.display = "none";
        retakeButton.style.display = "inline";
        captureButton.style.display = "none";

        capturedImageDataInput.value = imageDataURL;
    });

    retakeButton.addEventListener("click", function() {
        const webcamVideo = document.getElementById("webcamVideo");

        webcamVideo.style.display = "block";
        capturedImage.style.display = "none";
        captureButton.style.display = "inline";
        retakeButton.style.display = "none";

        capturedImageDataInput.value = "";
    });
});


                    
                </script>
                
                    
                    ';
                    
                
               }
              
              
              
               if ($questionRow['answer_type'] == 'voiceMemo') {
                echo '
                <style>
                  #recorder {
                    border: 2px solid #333;
                    border-radius: 10px;
                    padding: 20px;
                    width: 300px;
                    margin: 0 auto;
                  }
                  #recordingDisplay, #mediaPlayer {
                    text-align: center;
                    margin-bottom: 20px;
                  }
                  audio {
                    width: 100%;
                  }
                  a {
                    display: inline-block;
                    margin: 5px;
                    padding: 10px 20px;
                    border: none;
                    background-color: #007bff;
                    color: #fff;
                    border-radius: 5px;
                    cursor: pointer;
                    text-decoration: none;
                  }
                  a.disabled {
                    background-color: red;
                    cursor: not-allowed;
                  }
                </style>
                
                <div id="recorder">
                <p><strong>Please record your voice</strong></p>
                  <div id="recordingDisplay"></div>
                  <div id="mediaPlayer"></div>
                  <a href="#" id="toggleRecording">Start Recording</a>
                  <form id="recordingForm" method="post" action="save_recording.php">
                    <input type="hidden" name="voicerecording" id="recordingData">
                  </form>
                </div>
                
                <script>
                  let mediaRecorder;
                  let recordedChunks = [];
                  let isRecording = false;
                
                  const toggleRecordingLink = document.getElementById(\'toggleRecording\');
                  const recordingDisplay = document.getElementById(\'recordingDisplay\');
                  const mediaPlayer = document.getElementById(\'mediaPlayer\');
                  const recordingDataInput = document.getElementById(\'recordingData\');
                
                  toggleRecordingLink.addEventListener(\'click\', toggleRecording);
                
                  async function toggleRecording(event) {
                    event.preventDefault();
                
                    if (!isRecording) {
                      try {
                        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                        mediaRecorder = new MediaRecorder(stream);
                        mediaRecorder.ondataavailable = event => {
                          recordedChunks.push(event.data);
                        };
                        mediaRecorder.onstop = async () => {
                          const blob = new Blob(recordedChunks, { type: \'audio/webm\' });
                          const reader = new FileReader();
                          reader.readAsDataURL(blob);
                          reader.onloadend = () => {
                            const base64String = reader.result.split(",")[1];
                            recordingDisplay.innerHTML = `<audio controls src="${reader.result}"></audio>`;
                            recordingDataInput.value = base64String;
                            recordedChunks = [];
                            toggleRecordingLink.textContent = \'Start Recording\';
                            toggleRecordingLink.classList.remove(\'disabled\');
                            isRecording = false;
                          };
                        };
                        mediaRecorder.start();
                        toggleRecordingLink.textContent = \'Stop Recording...\';
                        toggleRecordingLink.classList.add(\'disabled\');
                        isRecording = true;
                      } catch (error) {
                        console.error(\'Error accessing microphone:\', error);
                        alert(\'Error accessing microphone. Please check your microphone settings.\');
                      }
                    } else {
                      mediaRecorder.stop();
                      toggleRecordingLink.textContent = \'Start Recording\';
                      toggleRecordingLink.classList.remove(\'disabled\');
                      isRecording = false;
                    }
                  }
                </script>';
            }
                // Display "Next" button for all questions except the last one
                if (count($_SESSION['questionIds']) > 0) {
                    echo '<button type="submit" onclick="stopTimer()" class="button-27 next-step" >Next</button>';
                } else {
                    // Display "Submit" button for the last question
                    echo '<button type="submit"  onclick="stopTimer()" class="button-27 next-step" >Submit</button>';
                }


                echo '<style>
                body {
                    font-family: Arial, sans-serif;
                }
                .tabs {
                    display: flex;
                    margin-top: 20px;
                }
                .tab {
                    flex: 1;
                    text-align: center;
                    padding: 10px 20px;
                    background-color: #f0f0f0;
                    cursor: pointer;
                    border: 1px solid #ccc;
                    border-bottom: none;
                }
                .tab:hover {
                    background-color: #161515;
                    color: white;
                }
                .tab.active {
                    background-color: #ccc;
                }
                .tab-content {
                    display: none;
                    padding: 20px;
                    border: 1px solid #ccc;
                    border-top: none;
                }
                .tab-content.active {
                    display: block;
                }
            </style>
            </head>
            <body>
            <div class="tabs">
                <div class="tab" id="answerTab">Show Answer</div>
                <div class="tab" id="explanationTab">Show Explanation</div>
            </div>
            <div class="tab-content" id="answerContent">
                <!-- Answer content goes here -->';
                if ($questionRow['answer_type'] == 'cameraImage') {
                    echo "<div class='image-preview'><img src='" . $questionRow['answer'] . "' alt='Answer Image' width='400px' height='300px'></div>"; 
                } elseif ($questionRow['answer_type'] == 'voiceMemo') {
                    echo "<div class='audio-preview'><audio controls>
                            <source src='".$questionRow['answer'] . "' type='audio/webm'>
                            Your browser does not support the audio element.
                        </audio></div>"; 
                } elseif ($questionRow['answer_type'] == 'image') {
                    echo "<div class='image-preview'><img src='" . $questionRow['answer'] . "' alt='Answer Image' width='400px' height='300px'></div>"; 
                } else { 
                    echo $questionRow['answer']; 
                }



                echo '
            </div>
            <div class="tab-content" id="explanationContent">
                <!-- Explanation content goes here -->
                '.$questionRow["explanation"].'
            </div>
            
            <script>
                // Get the tabs and tab content elements
                var answerTab = document.getElementById("answerTab");
                var explanationTab = document.getElementById("explanationTab");
                var answerContent = document.getElementById("answerContent");
                var explanationContent = document.getElementById("explanationContent");
            
                // Add click event listeners to tabs
                answerTab.addEventListener("click", function() {
                    answerTab.classList.add("active");
                    explanationTab.classList.remove("active");
                    answerContent.classList.add("active");
                    explanationContent.classList.remove("active");
                });
            
                explanationTab.addEventListener("click", function() {
                    answerTab.classList.remove("active");
                    explanationTab.classList.add("active");
                    answerContent.classList.remove("active");
                    explanationContent.classList.add("active");
                });
            </script>';


                echo '</div>';
                
            } else {
                echo "Question not found.";
            }
        } else {
                // Your code here
                echo "No more questions available.";

                // Now redirect
                header('Location: thank_you.php');
                ob_end_flush(); // Flush the output buffer and send the output
                exit;
        }
        
        // Close the statement and database connection
        $questionStmt->close();
        $link->close();
        ?>
    </form>
</div>
<script>
        startTimer();
    </script>
    <script>
        function previewImage(event) {
            var fileInput = event.target;
            var imagePreview = document.getElementById('imagePreview');

            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                }

                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    </script>
</body>
</html>

