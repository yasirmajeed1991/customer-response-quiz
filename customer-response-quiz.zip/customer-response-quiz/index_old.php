<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Step Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container mt-5">
    <div id="timer" class="mb-4"></div>
    <form id="quizForm" action="submit_quiz.php" method="post">
        <input type="hidden" name="userId" id="userId" value="0">
        <input type="hidden" name="timerValue" id="timerValue" value="0">

        <!-- Step 1: Candidate Information -->
        <div id="step1" class="form-step">
            <h2>Fill your information and start the quizz</h2>
            <div class="form-group">
                <label for="candidateName">Name:</label>
                <input type="text" class="form-control" id="candidateName" name="name" >
            </div>
            <div class="form-group">
                <label for="phoneNumber">Phone Number:</label>
                <input type="tel" class="form-control" id="phoneNumber" name="number" >
            </div>

            <button type="button" class="button-27 start-quiz">Start</button>
        </div>

        <!-- Step 2: Quiz Questions -->
        <?php
        // Include your database connection
        include_once "admin/connection.php"; // Update this to your actual connection file

        // Fetch questions from the database
        $sql = "SELECT * FROM questions WHERE status = 1 ORDER BY RAND()";
        $result = $link->query($sql);

        if ($result->num_rows > 0) {
            $questionNumber = 1;
            while ($row = $result->fetch_assoc()) {
                echo '<div class="form-step">';
                echo '<h2>Question ' . $questionNumber . ':</h2>';
                echo '<div class="form-group">';
                echo '<label for="question' . $questionNumber . '">' . $row['question_text'] . '</label>';

                // Check if it's a radio-type question
                if ($row['question_type'] == 'radio') {
                    // Fetch choices for radio questions
                    $questionId = $row['id'];
                    $choicesSql = "SELECT choice_text FROM choices WHERE question_id = $questionId";
                    $choicesResult = $link->query($choicesSql);

                    if ($choicesResult->num_rows > 0) {
                        echo '<div class="form-check">';
                        $choices = ['a', 'b', 'c', 'd', 'e','f'];  // Add more letters if needed

                        $index = 0;  // Initialize index for choices array

                        while ($choice = $choicesResult->fetch_assoc()) {
                            $letter = $choices[$index];  // Get the corresponding letter from the choices array

                            echo '<input data-question="'.$row['question_text'].'" type="radio" class="form-check-input" name="question' . $questionNumber . '" value="' . $letter . '" required>';
                            echo '<label class="form-check-label" for="question' . $questionNumber . '">' . $letter . '. ' . $choice['choice_text'] . '</label><hr><br>';

                            $index++;  // Move to the next letter
                        }
                        echo '</div>';
                    }
                }  
                elseif ($row['question_type'] == 'camera')  {
                    // For camera questions
            echo '<input data-question="'.$row['question_text'].'" type="hidden" class="form-control" id="question' . $questionNumber . '" name="question' . $questionNumber . '" required>';
            
            echo '<style>
                #cameraContainer {
                  margin-bottom: 20px;
                }
                #capturedImage {
                  margin-top: 20px;
                }
                </style>';
                
            echo '<div id="cameraContainer">
                    <video id="cameraFeed" width="400" height="300" autoplay></video>
                    <button id="captureBtn">Capture</button>
                </div>
                <canvas id="canvas" width="400" height="300" style="display: none;"></canvas>
                <img id="capturedImage" src="" alt="Captured Image" style="display: none;">
                <button id="retakeBtn" style="display: none;">Retake</button>';

            echo '<script>
                // Get access to the camera
                navigator.mediaDevices.getUserMedia({ video: true })
                  .then(function(stream) {
                    var video = document.getElementById("cameraFeed");
                    video.srcObject = stream;
                    video.play();
                  })
                  .catch(function(err) {
                    console.error("Error accessing camera:", err);
                  });

                // Capture image from the camera feed
                document.getElementById("captureBtn").addEventListener("click", function() {
                  var video = document.getElementById("cameraFeed");
                  var canvas = document.getElementById("canvas");
                  var context = canvas.getContext("2d");
                  context.drawImage(video, 0, 0, canvas.width, canvas.height);

                  var imageDataURL = canvas.toDataURL("image/png");
                  var capturedImage = document.getElementById("capturedImage");
                  capturedImage.src = imageDataURL;
                  capturedImage.style.display = "block";

                  // Set the value of the hidden input field
                  document.getElementById("question' . $questionNumber . '").value = imageDataURL;

                  video.style.display = "none";
                  this.style.display = "none";
                  document.getElementById("retakeBtn").style.display = "block";
                });

                // Retake image
                document.getElementById("retakeBtn").addEventListener("click", function() {
                  var video = document.getElementById("cameraFeed");
                  var capturedImage = document.getElementById("capturedImage");
                  capturedImage.src = "";
                  capturedImage.style.display = "none";

                  video.style.display = "block";
                  document.getElementById("captureBtn").style.display = "block";
                  this.style.display = "none";
                });
                </script>';

                }
                elseif ($row['question_type'] == 'voice') {
                    // For voice questions
                    echo '<input data-question="'.$row['question_text'].'" type="hidden" class="form-control" id="question' . $questionNumber . '" name="question' . $questionNumber . '" required>';
                    
                    echo '<style>
                        #voiceRecording {
                          margin-bottom: 20px;
                        }
                        </style>';
                        
                    echo '<div id="voiceRecording">
                            <button id="recordBtn">Start Recording</button>
                            <button id="stopBtn" style="display: none;">Stop Recording</button>
                            <audio id="recordedAudio" controls style="display: none;"></audio>
                        </div>';
                
                    echo '<script>
                        let mediaRecorder;
                        let chunks = [];
                
                        navigator.mediaDevices.getUserMedia({ audio: true })
                          .then(function(stream) {
                            mediaRecorder = new MediaRecorder(stream);
                            mediaRecorder.ondataavailable = function(e) {
                              chunks.push(e.data);
                            };
                            mediaRecorder.onstop = function() {
                              const blob = new Blob(chunks, { type: "audio/webm" });
                              const audioUrl = URL.createObjectURL(blob);
                              const audio = document.getElementById("recordedAudio");
                              audio.src = audioUrl;
                              audio.style.display = "block";
                              document.getElementById("question' . $questionNumber . '").value = audioUrl;
                              chunks = [];
                            };
                          })
                          .catch(function(err) {
                            console.error("Error accessing microphone:", err);
                          });
                
                        document.getElementById("recordBtn").addEventListener("click", function() {
                          mediaRecorder.start();
                          document.getElementById("recordBtn").style.display = "none";
                          document.getElementById("stopBtn").style.display = "block";
                        });
                
                        document.getElementById("stopBtn").addEventListener("click", function() {
                          mediaRecorder.stop();
                          document.getElementById("recordBtn").style.display = "block";
                          document.getElementById("stopBtn").style.display = "none";
                        });
                        </script>';
                }
                
                else{
                     // For text input questions
                    echo '<input data-question="'.$row['question_text'].'" type="text" class="form-control" id="question' . $questionNumber . '" name="question' . $questionNumber . '" required>';
                    
                }

                echo '</div>';

                // Display "Next" button for all questions except the last one
                if ($questionNumber < $result->num_rows) {
                    echo '<button type="button" class="button-27 next-step">Next</button>';
                } else {
                    // Display "Submit" button for the last question
                    echo '<button type="submit" class="button-27 next-step">Submit</button>';
                }

                echo '</div>';
                $questionNumber++;
            }
        } else {
            echo '<p>No questions found.</p>';
        }

        // Close the database connection
        $link->close();
        ?>

        <!-- Step 3: Results -->
        <div id="step3" class="form-step">
            <h2>Sending ...</h2>
        </div>
    </form>
</div>

<script>
    $(document).ready(function () {
        var timer; // Variable to store the timer
        var startTime; // Variable to store the start time

        $('.form-step').hide();
        $('#step1').show();

        // Function to navigate between form steps
        function navigateToStep(step) {
            $('.form-step').hide();
            $(step).show();
        }

        // Start quiz button click event
        $('.start-quiz').click(function () {

            if($('#candidateName').val() && $('#phoneNumber').val() ){
                // Send AJAX request to first_submit.php
                startTime = new Date().getTime();
                timer = setInterval(updateTimer, 1000);
                var currentStep = $(this).closest('.form-step');
                navigateToStep(currentStep.next('.form-step'));
                $.ajax({
                    type: 'POST',
                    url: 'first_submit.php',
                    data: {
                        name: $('#candidateName').val(),
                        number: $('#phoneNumber').val()
                    },
                    success: function (userId) {
                        $('#userId').val(userId);
                    },
                    error: function (xhr, status, error) {
                        console.error(error);
                    }
                });
            } else {
                alert('fill your name and phone number')
            }


        });

        // Next step button click event
        $('.next-step').click(function () {
            // Move to the next step only if the input is valid
            var currentStep = $(this).closest('.form-step');
            var inputField = currentStep.find('input[type="text"], input[type="radio"]:checked');

            if (inputField.length > 0 && inputField[0].checkValidity()) {
                $val = inputField.val();
                $timer = $('#timer').text().replace('Time: ', '').replace(' seconds', '');
                inputField.val( '<b>'+inputField.attr('name') + '</b> : '+ $val + ' <br> time : ' + $timer + ' seconds <br> <hr>' );
                startTime = new Date().getTime();
                navigateToStep(currentStep.next('.form-step'));
                var responses = inputField.val();
                // Send AJAX request to next_submit.php
                $.ajax({
                    type: 'POST',
                    url: 'next_submit.php',
                    data: {
                  