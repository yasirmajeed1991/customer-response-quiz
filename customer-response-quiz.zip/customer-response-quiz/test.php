<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'mail.quest001.com'; // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'quizz@quest001.com'; // Replace with your cPanel email address
    $mail->Password = 'V@F5k+Su28T='; // Replace with your email password
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;
    $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);

    // Sender
    $mail->setFrom('quizz@quest001.com', 'Your Name'); // Replace with your cPanel email address and your name

    // Recipient
    $mail->addAddress('gaddariowen@gmail.com'); // Replace with the recipient's email address

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Subject of the email';
    $mail->Body = 'This is the body of the email.';

    $mail->send();
    echo 'Email sent successfully!';
} catch (Exception $e) {
    echo 'Error sending email: ', $mail->ErrorInfo;
}
?>
