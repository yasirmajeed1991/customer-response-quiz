<?php
// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
  header("location: ./login.php");
  exit;
}

include_once "connection.php";



require "header.php";
?>

<div class="pagetitle">
  <h1>Home</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>

      <li class="breadcrumb-item active">Home</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section d-inline-flex justify-content-around gap-4 w-100">

</section>


<?php
require "footer.php";
?>


