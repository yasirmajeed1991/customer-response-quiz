<?php
// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
    header("location: ../login.php");
    exit;
}
// Include your database connection
include_once "../connection.php";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Get the question ID from the GET parameters
    $questionId = $_GET["id"];

    // Fetch the image file path from the question_image table
    $fetchImagePathSql = "SELECT image_path FROM question_image WHERE question_id = ?";
    $fetchImagePathStmt = $link->prepare($fetchImagePathSql);
    $fetchImagePathStmt->bind_param("i", $questionId);
    $fetchImagePathStmt->execute();
    $fetchImagePathStmt->bind_result($imagePath);
    $fetchImagePathStmt->fetch();
    $fetchImagePathStmt->close();

    // Fetch the answer path and answer_type from the questions table
    $fetchAnswerSql = "SELECT answer, answer_type FROM questions WHERE id = ?";
    $fetchAnswerStmt = $link->prepare($fetchAnswerSql);
    $fetchAnswerStmt->bind_param("i", $questionId);
    $fetchAnswerStmt->execute();
    $fetchAnswerStmt->bind_result($answerPath, $answerType);
    $fetchAnswerStmt->fetch();
    $fetchAnswerStmt->close();

    // Delete the image record from the question_image table
    $deleteImageSql = "DELETE FROM question_image WHERE question_id = ?";
    $deleteImageStmt = $link->prepare($deleteImageSql);
    $deleteImageStmt->bind_param("i", $questionId);
    $deleteImageStmt->execute();
    $deleteImageStmt->close();

    // Delete the choices associated with the question
    $deleteChoicesSql = "DELETE FROM choices WHERE question_id = ?";
    $deleteChoicesStmt = $link->prepare($deleteChoicesSql);
    $deleteChoicesStmt->bind_param("i", $questionId);
    $deleteChoicesStmt->execute();
    $deleteChoicesStmt->close();

    // Delete the question from the questions table
    $deleteQuestionSql = "DELETE FROM questions WHERE id = ?";
    $deleteQuestionStmt = $link->prepare($deleteQuestionSql);
    $deleteQuestionStmt->bind_param("i", $questionId);
    $deleteQuestionStmt->execute();
    $deleteQuestionStmt->close();

    // Delete the image file from the server if it exists
    if ($imagePath && file_exists($imagePath)) {
        unlink($imagePath); // Delete the file
    }

    // Delete the file in the answer path if the answer_type is 'image', 'cameraImage', or 'voiceMemo'
    if (in_array($answerType, ['image', 'cameraImage', 'voiceMemo']) && $answerPath && file_exists($answerPath)) {
        unlink($answerPath); // Delete the file
    }

    // Set notification
    $_SESSION['notification'] = '<div class="alert alert-danger" role="alert">Question Deleted Successfully!</div>';

    // Redirect to the same page
    header("location: ./index.php");
    exit;
} else {
    // If the request method is not GET
    echo "Invalid request method";
}

// Close the database connection
$link->close();
?>
