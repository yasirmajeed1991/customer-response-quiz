<?php
// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
    header("location: ../login.php");
    exit;
}
// Include your database connection
include_once "../connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get question ID and new status from the POST data
    $questionId = $_POST["question_id"];
    $newStatus = $_POST["new_status"];

    // Update the status in the database
    $updateSql = "UPDATE questions SET status = ? WHERE id = ?";
    $stmt = $link->prepare($updateSql);

    if ($stmt) {
        $stmt->bind_param("ii", $newStatus, $questionId);
        $stmt->execute();
        $stmt->close();
        $_SESSION['notification']='<div class="alert alert-info" role="alert">Question status has been updated successfully!</div>';
    } else {
        echo "Error preparing statement: " . $link->error;
    }
} else {
    // If the request method is not POST
    echo "Invalid request method";
}

// Close the database connection
$link->close();
?>
