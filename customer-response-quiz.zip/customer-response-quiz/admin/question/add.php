<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
    header("location: ../login.php");
    exit;
}

include_once "../connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get data from the form
    $questionText = $_POST['question_text'];
    $questionType = $_POST['question_type'];
    $answer_type = $_POST['answer_type'];
    $answer =$_POST['answer_text'];
    $explanation = $_POST['explanation'];

    if ($questionType == 'radio') {
        $answer_type = 'radio';
    }

    // Prepare the SQL statement for question insertion
    $sql = "INSERT INTO questions (question_text, question_type, status, answer, explanation, answer_type) VALUES (?, ?, 1, ?, ?, ?)";
    $stmt = $link->prepare($sql);
    if (!$stmt) {
        echo "Error preparing statement: " . $link->error;
        exit;
    }

    $stmt->bind_param("sssss", $questionText, $questionType, $answer, $explanation, $answer_type);
    if ($stmt->execute()) {
        $questionId = $link->insert_id; // Get the ID of the newly inserted question

        // If the question type is 'radio', process and insert choices
        if ($questionType == 'radio') {
            foreach ($_POST['choices'] as $choiceText) {
                $choiceText = $link->real_escape_string($choiceText);
                $sql = "INSERT INTO choices (question_id, choice_text) VALUES ('$questionId', '$choiceText')";
                if (!$link->query($sql)) {
                    echo "Error inserting choice: " . $link->error;
                    exit;
                }
            }
        }

        // If the question type is 'image', process the question image
        if ($questionType == 'image') {
            // Check if a file was uploaded
            if (isset($_FILES["fileInput"])) {
                $file = $_FILES["fileInput"];

                // Check if there is no error with the file upload
                if ($file["error"] === 0) {
                    // Process the uploaded file
                    $targetDir = "../../images/QuestionImage/";
                    $questionNo = sprintf('%08d', $questionId); // Format the question ID to have leading zeros
                    $targetFile = $targetDir . $questionNo . '_' . basename($file["name"]); // Append question number to file name

                    // Attempt to move the uploaded file to the target directory
                    if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                        // Insert the file path into the database
                        $imagePath = $targetFile;
                        $sql = "INSERT INTO question_image (question_id, image_path) VALUES (?, ?)";
                        $stmt = $link->prepare($sql);
                        $stmt->bind_param("ss", $questionId, $imagePath);
                        if ($stmt->execute()) {
                            echo "Image uploaded successfully!";
                        } else {
                            echo "Error inserting image path into the database: " . $stmt->error;
                        }
                    } else {
                        echo "Error uploading image.";
                    }
                } else {
                    echo "File upload error: " . $file["error"];
                }
            } else {
                echo "No file uploaded.";
            }
        }

        // Handling file uploads or recordings after the initial insert based on answer_type
        if ($answer_type == 'image' && isset($_FILES["fileInput2"])) {
            $file = $_FILES["fileInput2"];
            if ($file["error"] === 0) {
                $targetDir = "../../images/QuestionImage/";
                $questionNo = sprintf('%09d', $questionId);
                $targetFile = $targetDir . $questionNo . '_' . basename($file["name"]);
                if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                    $answer = $targetFile;
                    
                } else {
                    echo "Error uploading image.";
                }
            } else {
                echo "File upload error: " . $file["error"];
            }
        } elseif ($answer_type == 'voiceMemo' && !empty($_POST["voicerecording"])) {
            $recordingsDir = '../../recordings/';
            $filename = uniqid('recording_') . '.webm';
            $recordingData = $_POST['voicerecording'];
            $decodedData = base64_decode($recordingData);
            if (file_put_contents($recordingsDir . $filename, $decodedData) !== false) {
                $answer = $recordingsDir . $filename;
            } else {
                echo 'Error saving recording';
                exit;
            }
        } elseif ($answer_type == 'cameraImage' && !empty($_POST["capturedImageData"])) {
            $capturedImageData = $_POST["capturedImageData"];
            $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $capturedImageData));
            $filename = uniqid() . '.png';
            $folderPath = '../../images/CameraImages/';
            $filePath = $folderPath . $filename;
            if (file_put_contents($filePath, $imageData) !== false) {
                $answer = $filePath;
            } else {
                echo 'Error saving image';
                exit;
            }
        } else{
            $answer = $_POST['answer_text'];
        }

        // Update the answer field in the question table
        $sql = "UPDATE questions SET answer = ? WHERE id = ?";
        $stmt = $link->prepare($sql);
        $stmt->bind_param("si", $answer, $questionId);
        if ($stmt->execute()) {
            $_SESSION['notification'] = '<div class="alert alert-success" role="alert">Question has been added successfully!</div>';
           header("location: ./index.php");
        } else {
            echo "There is a problem in inserting record: " . $stmt->error;
        }

    } else {
        echo "Error: " . $sql . "<br>" . $link->error;
    }
}

require "../header.php";
?>



    <div class="pagetitle">
        <h1>Question</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                <li class="breadcrumb-item active">Questions</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section  ">
        <div class="card row p-4">
            <h2>Add Question</h2>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="questionType">Select the Question Type to Show to the User</label>
                    <select class="form-select" id="questionType" name="question_type" required>
                        <option value="text">Text Input</option>
                        <option value="image">Upload Image as Question</option>
                        <option value="radio">Radio Choices</option>
                        
                    </select>
                </div>
                <div class="form-group">
                    <label for="questionText">Question Text:</label>
                    <input type="text" class="form-control" id="questionText" name="question_text" required>
                </div>
                <!--Question Image Upload Section -->
                <div id="image_upload" style="display:none; padding-top: 15px;">
                    <div class="form-group" id="image_file">
                        <input type="file" class="form-control" name="fileInput" id="fileInput"  accept="image/*" onchange="previewImage(event)">
                        <img id="imagePreview" src="#" alt="Image Preview" style="display: none; max-width: 100%;  max-height: 300px;padding-top: 15px;">

                    </div>
                </div>
                <!-- Choices section (hidden by default) -->
                <div id="choicesSection" style="display:none;">
                    <div class="form-group" id="choicesContainer">
                        <label for="choice1">Choice 1:</label>
                        <input type="text" class="form-control" name="choices[]" >
                    </div>
                    <!-- Add more choices dynamically using JavaScript -->
                </div>
                <div class="form-group" id="answerType" >
                    <label for="answerType">Select the Answer Type for user to answer question</label>
                    <select class="form-select" id="answer_type" name="answer_type" required>
                        <option value="text">Text Input</option>
                        <option value="image">Upload Image as Answer</option>
                        <option value="cameraImage">Camera Image</option>
                        <option value="voiceMemo">Voice Memo</option>
                        
                        
                    </select>
                </div>
                <div class="form-group" id="answer_text">
                    <label for="answer" id="answer_label_all" >Provide your answer to the question:</label>
                    <label for="answer" id="answer_label_radio" style="display:none">Provide your correct answer to the question:</label>
                    <input type="text" class="form-control" id="answer_text" name="answer_text" > 
                    
                </div>
                <div id="answer_image_upload" style="display:none; padding-top: 15px;">
                    <div class="form-group" id="image_file">
                        <input type="file" class="form-control" name="fileInput2" id="fileInput2"  accept="image/*" onchange="previewImage2(event)">
                        <img id="imagePreview2" src="#" alt="Image Preview2" style="display: none; max-width: 100%;  max-height: 300px;padding-top: 15px;">
                    </div>
                </div>
                <div id="answer_camera_image" style="display:none;">
                <style>
                    /* Style for anchor buttons */
                    .button {
                        display: inline-block;
                        padding: 10px 20px;
                        margin: 10px;
                        background-color: #007bff;
                        color: #fff;
                        text-decoration: none;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                    }
                   
                
                    /* Container styles */
                    .row {
                        margin-top:20px;
                        display: flex;
                        margin-bottom: 20px;
                    }
                
                    #webcamContainer {
                        width: 500px;
                        height: 400px;
                        position: relative;
                    }
                
                    #capturedImage {
                        width: 500px;
                        height: 400px;
                        display: none;
                    }
                    #retakeButton {
                        background-color: #000;
                        color: #fff;
                    }
                </style>
                
                <!-- Webcam and Capture Elements -->
                <div class="row">
                <p><strong>Please capture an image from your camera for your answer!</strong></p>
                    <div id="webcamContainer">
                        <video id="webcamVideo" width="500" height="400" autoplay></video>
                        <img id="capturedImage" src="" alt="Captured Image">
                    </div>
                </div>
                
                <div class="row">
                    <div id="buttonContainer">
                        <a href="#" id="captureButton" class="button">Capture</a>
                        <a href="#" id="retakeButton" class="button" style="display: none;">Retake</a>
                    </div>
                </div>
                
                <!-- Hidden Field to Store Captured Image Data -->
                <input type="hidden" id="capturedImageData" name="capturedImageData">
                
               
                </div>
                <div id="answer_voice_memo" style="display:none;">
                
                <div id="recorder">
                <p><strong>Please record your voice for your answer!</strong></p>
                  <div id="recordingDisplay"></div>
                  <div id="mediaPlayer"></div>
                  <a href="#" id="toggleRecording">Start Recording</a>
                  
                    <input type="hidden" name="voicerecording" id="recordingData">
                 
                </div>
                
                </div>
                <div class="form-group">
                    <label for="explnation">Provide explanation to the question (optional):</label>
                    <input type="text" class="form-control" id="explnation" name="explanation" >
                </div>
                <div class="mt-4">
                    <!-- Button to add more choices -->
                    <button type="button" class="btn btn-success" id="addChoiceBtn" style="display:none;">Add Choice</button>
                    <button type="submit" class="btn btn-primary">Add Question</button>
                </div>
            </form>
        </div>
    </section>
<?php
require "../footer.php";
?>
<script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<script>
    $(document).ready(function () {
          // Function to stop all media streams
    function stopMediaStreams() {
        // Stop webcam stream
        if (window.stream) {
            window.stream.getTracks().forEach(track => track.stop());
            window.stream = null;
        }

        // Stop microphone stream
        if (window.audioStream) {
            window.audioStream.getTracks().forEach(track => track.stop());
            window.audioStream = null;
        }
    }
        // Event listener for question type change
        $('#questionType').change(function () {
            var selectedType = $(this).val();
            if (selectedType === 'radio') {
                $('#choicesSection').show();
                $('#addChoiceBtn').show();
                $('#image_upload').hide();
                $('#answer_label_all').hide();
                $('#answer_label_radio').show();
                $('#answerType').hide();
            } else {
                $('#choicesSection').hide();
                $('#addChoiceBtn').hide();
                $('#answerType').show();
            }
            if (selectedType == 'text') {
                $('#image_upload').hide();
                $('#answer_label_all').show();
                $('#answer_label_radio').hide();
            } else if (selectedType === 'image') {
                $('#image_upload').show();
                $('#answer_label_all').show();
                $('#answer_label_radio').hide();
            }
        });

        // Event listener for answer type change
        $('#answer_type').change(function () {
            var selectedType = $(this).val();
            if (selectedType == 'text') {
                $('#answer_text').show();
                $('#answer_image_upload').hide();
                $('#answer_camera_image').hide();
                $('#answer_voice_memo').hide();
            } else if (selectedType == 'image') {
                $('#answer_image_upload').show();
                $('#answer_text').hide();
                $('#answer_camera_image').hide();
                $('#answer_voice_memo').hide();
            } else if (selectedType == 'cameraImage') {
                $('#answer_camera_image').show();
                $('#answer_image_upload').hide();
                $('#answer_text').hide();
                $('#answer_voice_memo').hide();
                startCamera();
            } else if (selectedType == 'voiceMemo') {
                $('#answer_voice_memo').show();
                $('#answer_camera_image').hide();
                $('#answer_image_upload').hide();
                $('#answer_text').hide();
                startRecording();
            }
        });

        // Event listener for adding choices dynamically
        var choiceCount = 1; // Initial choice count
        $('#addChoiceBtn').click(function () {
            choiceCount++;
            var newChoiceHtml = '<div class="form-group">' +
                '<label for="choice' + choiceCount + '">Choice ' + choiceCount + ':</label>' +
                '<input type="text" class="form-control" name="choices[]">' +
                '</div>';
            $('#choicesContainer').append(newChoiceHtml);
        });
    });

    function startCamera() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
                const webcamVideo = document.getElementById("webcamVideo");
                webcamVideo.srcObject = stream;
            })
            .catch(function(err) {
                console.error("Error accessing webcam:", err);
            });

        const captureButton = document.getElementById("captureButton");
        const retakeButton = document.getElementById("retakeButton");
        const capturedImageDataInput = document.getElementById("capturedImageData");
        const capturedImage = document.getElementById("capturedImage");

        captureButton.addEventListener("click", function() {
            const webcamVideo = document.getElementById("webcamVideo");
            const canvas = document.createElement("canvas");
            const context = canvas.getContext("2d");

            canvas.width = webcamVideo.videoWidth;
            canvas.height = webcamVideo.videoHeight;
            context.drawImage(webcamVideo, 0, 0, canvas.width, canvas.height);

            const imageDataURL = canvas.toDataURL("image/png");

            capturedImage.src = imageDataURL;
            capturedImage.style.display = "block";
            webcamVideo.style.display = "none";
            retakeButton.style.display = "inline";
            captureButton.style.display = "none";
            capturedImageDataInput.value = imageDataURL;
        });

        retakeButton.addEventListener("click", function() {
            const webcamVideo = document.getElementById("webcamVideo");
            webcamVideo.style.display = "block";
            capturedImage.style.display = "none";
            captureButton.style.display = "inline";
            retakeButton.style.display = "none";
            capturedImageDataInput.value = "";
        });
    }

    function startRecording() {

        const style = document.createElement('style');
            style.type = 'text/css';
            style.innerHTML = `
                #recorder {
                    
                    padding: 20px;
                    width: 400px;
                    
                }
                #recordingDisplay, #mediaPlayer {
                    text-align: center;
                    margin-bottom: 20px;
                }
                audio {
                    width: 100%;
                }
                #recorder a {
                    display: inline-block;
                    margin: 5px;
                    padding: 10px 20px;
                    border: none;
                    background-color: #007bff;
                    color: #fff;
                    border-radius: 5px;
                    cursor: pointer;
                    text-decoration: none;
                }
                #recorder a.disabled {
                    background-color: red;
                    cursor: not-allowed;
                }
            `;
            document.head.appendChild(style);
            
        let mediaRecorder;
        let recordedChunks = [];
        let isRecording = false;
        const toggleRecordingLink = document.getElementById('toggleRecording');
        const recordingDisplay = document.getElementById('recordingDisplay');
        const mediaPlayer = document.getElementById('mediaPlayer');
        const recordingDataInput = document.getElementById('recordingData');

        toggleRecordingLink.addEventListener('click', toggleRecording);

        async function toggleRecording(event) {
            event.preventDefault();
            if (!isRecording) {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    mediaRecorder = new MediaRecorder(stream);
                    mediaRecorder.ondataavailable = event => {
                        recordedChunks.push(event.data);
                    };
                    mediaRecorder.onstop = async () => {
                        const blob = new Blob(recordedChunks, { type: 'audio/webm' });
                        const reader = new FileReader();
                        reader.readAsDataURL(blob);
                        reader.onloadend = () => {
                            const base64String = reader.result.split(",")[1];
                            recordingDisplay.innerHTML = `<audio controls src="${reader.result}"></audio>`;
                            recordingDataInput.value = base64String;
                            recordedChunks = [];
                            toggleRecordingLink.textContent = 'Start Recording';
                            toggleRecordingLink.classList.remove('disabled');
                            isRecording = false;
                        };
                    };
                    mediaRecorder.start();
                    toggleRecordingLink.textContent = 'Stop Recording...';
                    toggleRecordingLink.classList.add('disabled');
                    isRecording = true;
                } catch (error) {
                    console.error('Error accessing microphone:', error);
                    alert('Error accessing microphone. Please check your microphone settings.');
                }
            } else {
                mediaRecorder.stop();
                toggleRecordingLink.textContent = 'Start Recording';
                toggleRecordingLink.classList.remove('disabled');
                isRecording = false;
            }
        }




    }
</script>


<script>
        function previewImage2(event) {
            var fileInput2 = event.target;
            var imagePreview2 = document.getElementById('imagePreview2');
            if (fileInput2.files && fileInput2.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview2.src = e.target.result;
                    imagePreview2.style.display = 'block';
                }
                reader.readAsDataURL(fileInput2.files[0]);
            }
        }
    </script>

<script>
        function previewImage(event) {
            var fileInput = event.target;
            var imagePreview = document.getElementById('imagePreview');

            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                }
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
</script>