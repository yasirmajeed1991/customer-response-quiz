<?php
// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
    header("location: ../login.php");
    exit;
}

include_once "../connection.php";

require "../header.php";
?>

<style>
    td,th{
        text-align: center;
    }
    
    .border-right {
        border-right: 1px solid #ccc; padding: 8px;
    }
</style>

<div class="pagetitle">
    <h1>Questions</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Questions</li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<?php if($_SESSION['notification']){
        echo $_SESSION['notification'];
        $_SESSION['notification']=''; 
}?>

<section class="section  ">
    <div class="card row">
        <div class="container col-12 p-4">
            
           
           
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group mt-4">
                        <a href="add.php" class="btn btn-primary mb-2">Add question</a>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mt-4">
                        <label for="orderSelect" class="form-label">Selected Display Order: <?php
                                    // Include your database connection
                                    include_once "admin/connection.php";

                                    // Fetch the order status from the database
                                    $sql11 = "SELECT display_status FROM display_order WHERE id = 1";
                                    $result1 = $link->query($sql11);

                                    if ($result1->num_rows > 0) {
                                        $row1 = $result1->fetch_assoc();
                                        $orderStatus = $row1["display_status"];

                                        // Check the order status and echo the corresponding display text
                                        switch ($orderStatus) {
                                            case "id ASC":
                                                    echo '<span style="color: green;font-weight:bold">Ascending</span> ';
                                                    break;
                                                case "id DESC":
                                                    echo '<span style="color: green;font-weight:bold">Descending</span> ';
                                                    break;
                                                case "RAND()":
                                                    echo '<span style="color: green;font-weight:bold">Shuffled</span> ';
                                                    break;
                                                default:
                                                    echo "Unknown";
                                                    break;
                                        }
                                    } else {
                                        echo "Order status not found";
                                    }
                                    // Close the database connection
                                    ?>
                            </label>
                            <select id="orderSelect" class="form-select form-select-sm">
                                <option value="">Please Select Display Order</option>
                                <option value="id ASC">Ascending</option>
                                <option value="id DESC">Descending</option>
                                <option value="RAND()">Shuffled</option>
                            </select>   
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mt-4">
                        <label for="orderSelect" class="form-label">Mode of Quiz: <?php
                                    // Include your database connection
                                    include_once "admin/connection.php";

                                    // Fetch the order status from the database
                                    $sql_mode = "SELECT mode FROM quiz_mode WHERE id = 1";
                                    $result_mode = $link->query($sql_mode);

                                    if ($result_mode->num_rows > 0) {
                                        $row_result_mode = $result_mode->fetch_assoc();
                                        $modeStatus = $row_result_mode["mode"];

                                        // Check the order status and echo the corresponding display text
                                        switch ($modeStatus) {
                                            case "testing":
                                                    echo '<span style="color: green;font-weight:bold">Testing</span> ';
                                                    break;
                                                case "practicing":
                                                    echo '<span style="color: red;font-weight:bold">Practicing</span> ';
                                                    break;
                                                default:
                                                    echo "Unknown";
                                                    break;
                                        }
                                    } else {
                                        echo "mode  not found";
                                    }
                                    // Close the database connection
                                    ?>
                            </label>
                            <select id="modeSelect" class="form-select form-select-sm">
                                <option value="">Please choose quiz mode</option>
                                <option value="testing">Testing</option>
                                <option value="practicing">Practicing</option>
                                
                            </select>   
                        </div>
                    </div>
                </div>
       
                <table class="table  table-sm table-hover" style="border-collapse: collapse; width: 100%; border: 1px solid #ccc;">
    <thead>
    <tr style="background-color:#b4e4fc;">
        <th scope="col">ID</th>
        <th scope="col">Question Text</th>
        <th scope="col">Question Choices/Images</th>
        <th scope="col">Question Type</th>
        <th scope="col">Answer Type</th>
        <th scope="col">Answer</th>
        <th scope="col">Explanation</th>
        <th scope="col">Status</th>
        <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
    <?php
    // Fetch questions from the database
    $sql = "SELECT * FROM questions";
    $result = $link->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr style='border-bottom: 1px solid #ccc;'>";
            echo "<th class='border-right' scope='row'> " . $row["id"] . "</th>";
            echo "<td class='border-right'>" . $row["question_text"] . "</td>";
            echo "<td class='border-right'> <ul>";
            if ($row["question_type"] == 'radio') {
                // Fetch choices for radio questions
                $questionId = $row["id"];
                $choicesSql = "SELECT choice_text FROM choices WHERE question_id = $questionId";
                $choicesResult = $link->query($choicesSql);
                if ($choicesResult->num_rows > 0) {
                    while ($choice = $choicesResult->fetch_assoc()) {
                        echo "<li> ". $choice["choice_text"] . "</li>";
                    }
                }
            }
           elseif ($row["question_type"] == 'image') {
                // Fetch image path for image question
                $questionId_image = $row["id"];
                $imageSql = "SELECT image_path FROM question_image WHERE question_id = $questionId_image";
                $imageResult = $link->query($imageSql);
                // Check if there is a result
                if ($imageResult && $imageResult->num_rows > 0) {
                    // Fetch image path
                    $imageRow = $imageResult->fetch_assoc();
                    $imagePath = $imageRow["image_path"];
                    // Display the image as a clickable thumbnail
                    echo '<a href="#" class="question-link" data-toggle="modal" data-target="#questionModal" data-img="' . $imagePath . '">Click to View Question Image</a>';
                } else {
                    echo "No image found for this question.";
                }
                // Free the result set
                $imageResult->free();
            }
            else{
                echo 'Not Available';
            }
            echo "</ul></td>";
            echo "<td class='border-right'>" . $row["question_type"] . "</td>";
            echo "<td class='border-right'>" . $row["answer_type"] . "</td>";
            if ($row["question_type"] == 'radio') {
                echo "<td class='border-right'>" . $row["answer"] . "</td>";
            }else{
                if($row['answer_type']=='image' || $row['answer_type']=='cameraImage'){
                    $answerDetails = '<a href="#" class="answer-link" data-toggle="modal" data-target="#answerModal" data-img="' . $row["answer"] . '">Click To View Image</a>';
                }
                if($row['answer_type']=='voiceMemo'){
                    $answerDetails = '<a href="#" class="answer-link" data-toggle="modal" data-target="#answerModal" data-audio="' . $row["answer"] . '">Play Voice Memo</a>';
                }
                if($row['answer_type']=='text'){
                    $answerDetails = $row["answer"];
                }

                echo "<td class='border-right'>" . $answerDetails . "</td>";
            }
            
            if(empty($row["explanation"])){
                $explanation_quest='Not Available';
            } else {
                $explanation_quest=$row["explanation"];
            }

            echo "<td class='border-right'>" . $explanation_quest . "</td>";
            
            
            
            echo "<td class='border-right' >";
            echo "<div class='form-check form-switch'>";
            echo "<input class='form-check-input switch-btn' type='checkbox' data-id='" . $row["id"] . "' data-status='" . $row["status"] . "' " . ($row["status"] == 1 ? "checked" : "") . ">";
            echo "</div></td>";
            echo "<td class='border-right'><a href='#' class='delete-link' data-user-id='" . $row['id'] . "' class='btn btn-danger btn-sm ml-4'><i class='bi bi-trash'></i></a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No questions found.</td></tr>";
    }

    $link->close();
    ?>
    </tbody>
</table>

        </div>
    </div>
</section>

<?php
require "../footer.php";
?>
<!-- Question Modal -->
<div class="modal fade" id="questionModal" tabindex="-1" role="dialog" aria-labelledby="questionModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="questionModalLabel">Question Image</h5>
        
      </div>
      <div class="modal-body">
        <img id="questionImage" src="" alt="Question Image" class="img-fluid">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Answer Modal -->
<div class="modal fade" id="answerModal" tabindex="-1" role="dialog" aria-labelledby="answerModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="answerModalLabel">Answer</h5>
        
       
      </div>
      <div class="modal-body">
        <img id="answerImage" src="" alt="Answer Image" class="img-fluid">
        <audio id="answerAudio" controls class="d-none">
          <source id="answerAudioSource" src="" type="audio/mpeg">
          Your browser does not support the audio element.
        </audio>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
    $(document).ready(function () {
        // Event listener for switch button
        $('.switch-btn').click(function () {
            var questionId = $(this).data('id');
            var currentStatus = $(this).data('status');
            var newStatus = currentStatus == 1 ? 0 : 1;

            $.ajax({
                type: 'POST',
                url: 'switch.php',
                data: {
                    question_id: questionId,
                    new_status: newStatus
                },
                success: function (response) {
                    location.reload(); // Reload the page after successful switch
                },
                error: function (error) {
                    console.log(error);
                }
            });
        });
    });
</script>
<script>
        // Execute this code when the document is ready
        $(document).ready(function () {
            // Event listener for order select change
            $('#orderSelect').change(function () {
                // Get the selected value
                var order = $(this).val();

                // Send AJAX request to update question order
                $.ajax({
                    url: 'display_order.php', // Replace with your PHP file URL
                    type: 'POST',
                    data: { order: order },
                    success: function (response) {
                        // Reload the page after successful update
                        location.reload();
                    },
                    error: function (xhr, status, error) {
                        // Handle error response, if needed
                        console.error('Error updating question order: ' + error);
                    }
                });
            });
        });
    </script>
    <script>
        // Execute this code when the document is ready
        $(document).ready(function () {
            // Event listener for order select change
            $('#modeSelect').change(function () {
                // Get the selected value
                var mode = $(this).val();

                // Send AJAX request to update question order
                $.ajax({
                    url: 'quiz_mode.php', // Replace with your PHP file URL
                    type: 'POST',
                    data: { mode: mode },
                    success: function (response) {
                        // Reload the page after successful update
                        location.reload();
                    },
                    error: function (xhr, status, error) {
                        // Handle error response, if needed
                        console.error('Error updating  mode: ' + error);
                    }
                });
            });
        });

        $(document).ready(function(){
  // Question Modal
  $('#questionModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        var imgSrc = button.data('img'); // Extract info from data-* attributes
        var modal = $(this);

        // Add a cache-busting parameter to the image URL
        var cacheBuster = new Date().getTime(); // Generate a unique timestamp
        var updatedImgSrc = imgSrc + '?cb=' + cacheBuster;

        modal.find('.modal-body img').attr('src', updatedImgSrc);
    });

    // Answer Modal
    $('#answerModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        var imgSrc = button.data('img'); // Extract info from data-* attributes
        var audioSrc = button.data('audio'); // Extract info from data-* attributes
        var modal = $(this);

        // Add a cache-busting parameter to the image URL
        if (imgSrc) {
            var cacheBuster = new Date().getTime(); // Generate a unique timestamp
            var updatedImgSrc = imgSrc + '?cb=' + cacheBuster;
            modal.find('.modal-body img').attr('src', updatedImgSrc).removeClass('d-none');
            modal.find('.modal-body audio').addClass('d-none');
        }
        if (audioSrc) {
            modal.find('.modal-body audio').attr('src', audioSrc).removeClass('d-none');
            modal.find('.modal-body img').addClass('d-none');
        }
    });
});

    </script>

<script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<script>
    let table = new DataTable('.table');

    MathJax = {
        tex: {
            inlineMath: [['$', '$']],
            displayMath: [['$$', '$$']],
            processEscapes: true
        }
    };
    MathJax.Hub.Queue(["Typeset", MathJax.Hub, 'mathjax-output']);

</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var deleteLinks = document.querySelectorAll('.delete-link');

        deleteLinks.forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();

                var questionId = this.getAttribute('data-user-id');

                var confirmed = confirm("Are you sure you want to delete this data?");
                if (confirmed) {
                    window.location.href = "delete.php?id=" + questionId;
                }
            });
        });
    });
</script>