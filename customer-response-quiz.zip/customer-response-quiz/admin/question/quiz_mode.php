<?php
// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
    header("location: ../login.php");
    exit;
}
// Include your database connection
include_once "../connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get mode from the POST data
    $mode = $_POST["mode"];

    // Update the status in the database
    $updateSql = "UPDATE quiz_mode SET mode = ? WHERE id = 1";
    $stmt = $link->prepare($updateSql);

    if ($stmt) {
        $stmt->bind_param("s", $mode);
        $stmt->execute();
        $stmt->close();
        $_SESSION['notification'] = '<div class="alert alert-info" role="alert">Quiz Mode Has Been Changed Successfully!</div>';
    } else {
        echo "Error preparing statement: " . $link->error;
    }
} else {
    // If the request method is not POST
    echo "Invalid request method";
}

// Close the database connection
$link->close();
?>
