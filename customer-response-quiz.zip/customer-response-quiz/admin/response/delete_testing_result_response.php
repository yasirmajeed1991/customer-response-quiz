<?php
session_start(); // Start the session if not already started


include_once "../connection.php"; 
// Assume you have established a database connection already

// Check if user ID is provided in the URL
if (isset($_GET['user_id'])) {
    // Retrieve user ID from the URL parameter
    $userId = $_GET['user_id'];

  
            // Function to delete files
        function deleteFile($filePath) {
            // Add ../../ to the beginning of the file path
            $fullPath = "../../" . $filePath;
            
            if (file_exists($fullPath)) {
                unlink($fullPath);
            }
        }

    // Function to delete data related to a user_id
    function deleteUser($userId, $link) {
        // Step 1: Retrieve paths of image, voice, and camera files from user_response
        $query = "SELECT qr.answer, q.question_type ,q.answer_type
                  FROM user_response qr
                  JOIN questions q ON qr.question_id = q.id
                  WHERE qr.user_id = $userId";

        $result = $link->query($query);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                if ($row['answer_type'] == 'image' || $row['answer_type'] == 'cameraImage' || $row['answer_type'] == 'voiceMemo') {
                    // Delete file if question type is voice or camera
                    deleteFile($row['answer']);
                }
            }
        }

        // Step 2: Delete rows from user_response for the specified user_id
        $deleteResponseQuery = "DELETE FROM user_response WHERE user_id = $userId";
        $link->query($deleteResponseQuery);

        // Step 3: Delete rows from user_quiz for the specified user_id
        $deleteQuizQuery = "DELETE FROM user_quiz WHERE id = $userId";
        $link->query($deleteQuizQuery);
    }

    // Call the deleteUser function with the provided user_id
    deleteUser($userId, $link);
// Set notification
$_SESSION['notification'] = '<div class="alert alert-danger" role="alert">Quiz Record Deleted Successfully!</div>';
    // Redirect back to the previous page or any other desired location
    header("Location: index.php");
    exit();
} else {
    // If user ID is not provided in the URL, redirect to an error page or display an error message
    header("Location: error_page.php");
    exit();
}

// Close the database connection
$link->close();
?>
