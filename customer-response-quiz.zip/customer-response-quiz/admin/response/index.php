<?php
// Initialize the session
session_start();

if (!isset($_SESSION["inv_loggedin"]) || $_SESSION["inv_loggedin"] !== true) {
    header("location: ../login.php");
    exit;
}
include_once "../connection.php"; // Update this to your actual connection file

require "../header.php";
?>

<div class="pagetitle">
    <h1>Quiz Results</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active">Quiz Results</li>
        </ol>
    </nav>
</div><!-- End Page Title -->
<?php if($_SESSION['notification']){
        echo $_SESSION['notification'];
        $_SESSION['notification']=''; 
}?>
<section class="section">
    <div class="card row">
        <div class="container col-12 p-4">
            <table class="table table-sm table-hover" style="border-collapse: collapse; width: 100%; border: 1px solid #ccc;" id="quizResultsTable">
                <thead>
                <tr>
                   
                    <th >User ID</th>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Mode</th>
                    <th>Submission Date & Time</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                // Fetch quiz results from the database
                $sql = "SELECT * FROM user_quiz ";
                $result = $link->query($sql);

                if ($result->num_rows > 0) {
                    
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                       
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["name"] . "</td>";
                        echo "<td>" . $row["number"] . "</td>";
                        echo "<td>" . $row["mode"] . "</td>";
                        echo "<td>" . $row["date_time"] . "</td>";
                        echo "<td>";
                        echo "<a target='_blank' class='view-btn' href='testing_result_response.php?id=" . $row['id'] . "'>View &#128065;</a>"; // View button with eye symbol
                        echo "<a href='#' class='delete-link' data-user-id='" . $row['id'] . "'>Delete &#128465;</a>"; // delete button with trash symbol

                        echo "</td>";
                        echo "</tr>";
                        
                    }
                } else {
                    echo "<tr><td colspan='6'>No quiz results found.</td></tr>";
                }

                $link->close();
                ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<?php
require "../footer.php";
?>

<script>
    $(document).ready(function () {
        // Initialize DataTable
        let table = $('#quizResultsTable').DataTable();
    });
</script>
<script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<script>
    let table = new DataTable('.table', {
        order: [[0, 'desc']] // Order by the first column (index 0) in descending order
    });
    MathJax = {
        tex: {
            inlineMath: [['$', '$']],
            displayMath: [['$$', '$$']],
            processEscapes: true
        }
    };
    MathJax.Hub.Queue(["Typeset", MathJax.Hub, 'mathjax-output']);
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var deleteLinks = document.querySelectorAll('.delete-link');

        deleteLinks.forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();

                var userId = this.getAttribute('data-user-id');

                var confirmed = confirm("Are you sure you want to delete this data?");
                if (confirmed) {
                    window.location.href = "delete_testing_result_response.php?user_id=" + userId;
                }
            });
        });
    });
</script>
