<?php
// Include your database connection
include_once "admin/connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user information
    $userId = $_POST["userId"];  // Add this line to get the user ID from the AJAX request
    $responses = $_POST["responses"];
    $timer = $_POST["timerValue"];



    // Update data in the database
    $updateSql = "UPDATE quiz_results SET responses = CONCAT(responses, ?), timer = ? WHERE id = ?";
    $stmt = $link->prepare($updateSql);

    if ($stmt) {
        $stmt->bind_param("sss", $responses, $timer, $userId);
        $stmt->execute();

        echo "Quiz responses updated successfully!";
    } else {
        echo "Error preparing statement: " . $link->error;
    }

    // Close the database connection
    $stmt->close();
    $link->close();
}
?>
