<?php
// Include your database connection
include_once "admin/connection.php";

// Query to fetch the mode value
$mode_sql = "SELECT mode FROM quiz_mode WHERE id = 1";

// Execute the query
$result_mode = $link->query($mode_sql);

// Check if the query was successful
if ($result_mode) {
    // Fetch the mode value
    $row_mode = $result_mode->fetch_assoc();
    $mode = $row_mode['mode'];

    // Close the result set
    $result_mode->close();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = $_POST["name"];
    $number = $_POST["number"];
    $mode = $_POST["mode"]; // Assuming "mode" is the name attribute of the mode input field in your form

    // Prepare and execute the SQL query to insert data into the user_quiz table
    $sql = "INSERT INTO user_quiz (name, number, mode) VALUES (?, ?, ?)";
    $stmt = $link->prepare($sql);

    
    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("sss", $name, $number, $mode);
        
        // Set parameters and execute
        $name = $_POST['name'];
        $number = $_POST['number'];
        $mode = $_POST['mode'];
        $stmt->execute();

        // Get the ID of the inserted record
        $userId = $stmt->insert_id;

        // Close statement
        $stmt->close();

        // Start a new session with the user ID
        session_start();
        $displayOrderSql = "SELECT * FROM display_order WHERE id = 1 ";
        $displayOrderResult = $link->query($displayOrderSql);
        $displayOrderResultRow = $displayOrderResult->fetch_assoc();
        $displayOrder = $displayOrderResultRow['display_status'];
       // Fetch the questions from the database
        $questionIds = [];
        $questionSql = "SELECT id FROM questions WHERE status = 1 ORDER BY $displayOrder";
        $questionResult = $link->query($questionSql);
        // Loop through the result set and store the question IDs in an array
        while ($row = $questionResult->fetch_assoc()) {
            $questionIds[] = $row['id'];
        }
        // Store the question IDs in a session variable
        $_SESSION['questionIds'] = $questionIds;
        $_SESSION['currentQuestionId'] = array_shift($_SESSION['questionIds']);
        $_SESSION['questionNo'] = 1;
        $_SESSION['user_id'] = $userId;
        $_SESSION['mode'] =$mode;
        // Redirect to the quiz page
        if($mode=='testing'){
            header("location: testing_mode.php");
        }
        if($mode=='practicing'){
            header("location: practice_mode.php");
        }
        
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $link->error;
    }

    // Close the statement and database connection
    $stmt->close();
    $link->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Step Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container mt-5">
    <form id="quizForm" action="" method="post">
        <input type="hidden" name="userId" id="userId" value="0">
        <input type="hidden" name="timerValue" id="timerValue" value="0">
        <!-- Step 1: Candidate Information -->
        <div id="step1" class="form-step">
            <h2>Fill your information and start the quizz</h2>
            <div class="form-group">
                <label for="candidateName">Name:</label>
                <input type="text" class="form-control" id="candidateName" name="name" required>
            </div>
            <div class="form-group">
                <label for="phoneNumber">Phone Number:</label>
                <input type="tel" class="form-control" id="phoneNumber" name="number" required>
            </div>
            <input type="hidden" name="mode" value="<?php echo $mode; ?>">
            <button type="submit" class="button-27 start-quiz">Start</button>
        </div>
    </form>
</div>
</body>
</html>

