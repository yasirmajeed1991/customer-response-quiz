<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Webcam Capture</title>
<style>
#cameraContainer {
  margin-bottom: 20px;
}
#capturedImage {
  margin-top: 20px;
}
</style>
</head>
<body>
<div id="cameraContainer">
  <video id="cameraFeed" width="400" height="300" autoplay></video>
  <button id="captureBtn">Capture</button>
</div>
<canvas id="canvas" width="400" height="300" style="display: none;"></canvas>
<img id="capturedImage" src="" alt="Captured Image" style="display: none;">
<button id="retakeBtn" style="display: none;">Retake</button>
<script>
// Get access to the camera
navigator.mediaDevices.getUserMedia({ video: true })
  .then(function(stream) {
    var video = document.getElementById('cameraFeed');
    video.srcObject = stream;
    video.play();
  })
  .catch(function(err) {
    console.error('Error accessing camera:', err);
  });

// Capture image from the camera feed
document.getElementById('captureBtn').addEventListener('click', function() {
  var video = document.getElementById('cameraFeed');
  var canvas = document.getElementById('canvas');
  var context = canvas.getContext('2d');
  context.drawImage(video, 0, 0, canvas.width, canvas.height);

  var imageDataURL = canvas.toDataURL('image/png');
  var capturedImage = document.getElementById('capturedImage');
  capturedImage.src = imageDataURL;
  capturedImage.style.display = 'block';

  video.style.display = 'none';
  this.style.display = 'none';
  document.getElementById('retakeBtn').style.display = 'block';
});

// Retake image
document.getElementById('retakeBtn').addEventListener('click', function() {
  var video = document.getElementById('cameraFeed');
  var capturedImage = document.getElementById('capturedImage');
  capturedImage.src = "";
  capturedImage.style.display = 'none';

  video.style.display = 'block';
  document.getElementById('captureBtn').style.display = 'block';
  this.style.display = 'none';
});
</script>
</body>
</html>
