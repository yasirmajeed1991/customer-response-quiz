<?php
// Include your database connection
include_once "admin/connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user information
    $name = $_POST["name"];
    $number = $_POST["number"];

    // Insert data into the database
    $insertSql = "INSERT INTO quiz_results (name, number) VALUES (?, ?)";
    $stmt = $link->prepare($insertSql);

    if ($stmt) {
        $stmt->bind_param("ss", $name, $number);
        $stmt->execute();

        // Retrieve the last inserted user ID
        $userId = $link->insert_id;


        //send mail

        $api_url = 'https://api.resend.com/emails';
        $api_key = 're_Ee4Qes4U_N9yR1i4wzZ6swKUU3oZZMn9u';

        $data = array(
            'from' => 'onboarding@resend.dev',
            'to' => 'flowers22888@hotmail.com',
            'subject' => 'New Submission',
            'html' => '<p>New quiz <strong>Submission</strong>!</p>',
        );

        $ch = curl_init($api_url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $api_key,
            'Content-Type: application/json',
        ));

        $response = curl_exec($ch);

        curl_close($ch);

        // Return the user ID as a response
        echo $userId;
    } else {
        echo "Error preparing statement: " . $link->error;
    }

    // Close the database connection
    $stmt->close();
    $link->close();
}
?>