<?php
// Assume you have established a database connection already

session_start(); // Start the session if not already started


include_once "admin/connection.php"; 
// Fetch user details
$user_id = $_GET['id'];
$user_query = "SELECT * FROM user_quiz WHERE id = $user_id";
$result_mode = $link->query($user_query);

// Check if the query was successful
if ($result_mode) {
    // Fetch user data
    $user_data = $result_mode->fetch_assoc();
} else {
    // Handle query error
    echo "Error: " . $link->error;
    exit; // Stop executing further
}

// Fetch user responses for the quiz
$user_responses_query = "SELECT qr.*, q.question_text, q.answer AS correct_answer, q.explanation, q.question_type, qi.image_path
FROM user_response qr
JOIN questions q ON qr.question_id = q.id
LEFT JOIN question_image qi ON q.id = qi.question_id
WHERE qr.user_id =  $user_id";
$user_responses_result = $link->query($user_responses_query);

// Close the database connection
$link->close();



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Step Form</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<style>
        /* Add your CSS styles for the result display here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .user-info {
            margin-bottom: 20px;
        }
        .response {
            border-bottom: 1px solid #ccc;
            padding: 10px 0;
        }
        .question {
            font-weight: bold;
        }
        .answer {
            margin-top: 5px;
            font-style: italic;
        }
        .explanation {
            color: #888;
        }
        .correct-answer {
            color: green;
        }
        .wrong-answer {
            color: red;
        }
    </style>
<div class="container mt-5">
    <!-- Step 3: Results -->
    <div class="text-center mt-5 mb-5">
        <h1>Thank You for taking the quiz</h1>
    </div>    
    <div class="text-center mt-5 mb-5">
        <div class="container">
            <h1>Quiz Results</h1>
            <div class="user-info">
                <p><strong>Name:</strong> <?php echo $user_data['name']; ?></p>
                <p><strong>Number:</strong> <?php echo $user_data['number']; ?></p>
            </div>
            <h2>Responses:</h2>
            <?php $sum=1; while ($response = $user_responses_result->fetch_assoc()) { ?>
                <div class="response">
                    <p class="question"><strong>Question <?php echo $sum;?>: </strong><?php echo $response['question_text']; ?></p>
                    <?php if ( $response['image_path']) { 
                        $image_path = substr($response['image_path'], 6); // Remove the first 6 characters
                        echo "<img src='" . $image_path. "' width='400px' height='300px'>";
                     }?>
                    <?php if ( $response['question_type'] == 'camera' || $response['question_type'] == 'voice') { ?>
                        <p class="answer" style="background-color: #f0f8ff; /* Light blue color */ padding: 10px; border-radius: 5px;">
                            This question requires manual review.
                        </p>
                    <?php }
                    else { ?>
                        <p class="answer <?php echo ($response['answer'] == $response['correct_answer']) ? 'correct-answer' : 'wrong-answer'; ?>">
                            <strong>Your Answer:</strong> <?php echo $response['answer']; ?>
                            <?php if ($response['answer'] == $response['correct_answer']) { ?>
                                <span class="checkmark">&#10004;</span>
                            <?php } else { ?>
                                <span class="cross">&#10008;</span>
                            <?php } ?>
                        </p>
                        <p class="answer">
                            <strong>Elapsed time for this question: </strong> 
                                        <?php
                                        $elapsed_seconds = $response['elapsed_time'];

                                        if ($elapsed_seconds < 60) {
                                            // If elapsed time is less than 60 seconds, display in seconds
                                            echo $elapsed_seconds . " seconds";
                                        } else {
                                            // If elapsed time is 60 seconds or more, convert to minutes
                                            $elapsed_minutes = floor($elapsed_seconds / 60);
                                            echo $elapsed_minutes . " minutes";
                                        }
                                        ?>

                        </p>
                        <p class="answer">
                            <strong>Correct Answer:</strong> <?php echo $response['correct_answer']; ?>
                        </p>
                        <?php if($response['explanation']){?>
                        <p class="explanation">
                            <strong>Explanation : </strong><?php echo $response['explanation']; ?>
                        </p>
                        <?php } ?>
                    <?php } ?>
                </div>
                <?php $sum=$sum+1;} ?>
        </div>
    </div>    
</div>


            
     
